package com.android.gs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.appstate.AppState;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.OnStateDeletedListener;
import com.google.android.gms.appstate.OnStateListLoadedListener;
import com.google.android.gms.appstate.OnStateLoadedListener;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.OnPlayersLoadedListener;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.google.android.gms.games.achievement.Achievement;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.OnAchievementUpdatedListener;
import com.google.android.gms.games.achievement.OnAchievementsLoadedListener;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardBuffer;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.google.android.gms.games.leaderboard.OnLeaderboardMetadataLoadedListener;
import com.google.android.gms.games.leaderboard.OnLeaderboardScoresLoadedListener;
import com.google.android.gms.games.leaderboard.OnScoreSubmittedListener;
import com.google.android.gms.games.leaderboard.SubmitScoreResult;
import com.google.example.games.basegameutils.GameHelper;
import com.google.example.games.basegameutils.GameHelperListener;
import com.google.example.games.basegameutils.GameHelperStateListener;
import com.unity3d.player.UnityPlayer;

public class GameClientManager implements GameHelperListener,
		GameHelperStateListener {

	protected GameHelper mHelper;

	public static final int ACHIEVEMENTS_REQUEST = 20001;
	public static final int LEADER_BOARDS_REQUEST = 20002;

	public static final String CONNECTION_LISTNER_NAME = "GooglePlayConnection";
	public static final String PlAY_SERVICE_LISTNER_NAME = "GooglePlayManager";
	public static final String GOOGLE_CLOUD_LISTNER_NAME = "GoogleCloudManager";
	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_EOF = "endofline";

	// stores any additional scopes.
	private String[] mAdditionalScopes;
	private int mClients = GameHelper.CLIENT_GAMES;

	protected String mDebugTag = "BaseGameActivity";
	protected boolean mDebugLog = false;

	private Activity _act;

	private static boolean isStarted = false;
	private static boolean isUnityPartInited = false;

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	public void startPlayService(Activity act, String clientToUse) {
		if (!isStarted()) {
			mClients = Integer.parseInt(clientToUse);
			onCreate(act);
			onStart(act);
			isStarted = true;
		}
	}

	private void onCreate(Activity act) {

		_act = act;
		mHelper = new GameHelper(act);
		mHelper.setup(this, this, mClients, mAdditionalScopes);

	}

	public void onStart(Activity act) {
		if(isStarted) {
			if(mHelper != null) {
				mHelper.onStart(act);
			}
		}
		
	}

	// --------------------------------------
	// SHOULD BE REFERED FROM ACTIVITY
	// --------------------------------------

	public void onStop() {
		mHelper.onStop();
	}

	public void onActivityResult(int request, int response, Intent data) {
		if (request == ACHIEVEMENTS_REQUEST) {
			printLog("ACHIEVEMENTS_REQUEST returned");
		}

		mHelper.onActivityResult(request, response, data);
	}

	// --------------------------------------
	// CLOUD METHODS
	// --------------------------------------

	public void listStates() {
		mHelper.getAppStateClient().listStates(new OnStateListLoadedListener() {

			@Override
			public void onStateListLoaded(int statusCode, AppStateBuffer buffer) {
				printLog("listStates Status: " + statusCode);
				printLog("listStates Count: " + buffer.getCount());

				StringBuilder result = new StringBuilder();
				result.append(statusCode);

				// TODO Auto-generated method stub
				Iterator<AppState> iterator = buffer.iterator();

				// boolean first = true;
				while (iterator.hasNext()) {

					AppState st = iterator.next();
					String data = ConvertCloudDataToString(st.getLocalData());

					result.append(UNITY_SPLITTER);
					result.append(st.getKey());
					result.append(UNITY_SPLITTER);
					result.append(data);

					printLog(data);
				}

				if (buffer.getCount() > 0) {
					result.append(UNITY_EOF);
				}

				UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
						"OnAllStatesLoaded", result.toString());

			}
		});
	}

	public void resolveState(int stateKey, String resolvedData, String resolvedVersion) {
	
		byte[] stateData = ConvertStringToCloudData(resolvedData);
		mHelper.getAppStateClient().resolveState(
				new OnStateLoadedListener() {

					@Override
					public void onStateLoaded(int statusCode, int stateKey,
							byte[] localData) {
						String data = "";
						printLog("resolveState onStateLoaded Status: "
								+ statusCode + " stateKey: " + stateKey);
						
						data = ConvertCloudDataToString(localData);
					

						StringBuilder result = new StringBuilder();
						result.append(statusCode);
						result.append(UNITY_SPLITTER);
						result.append(stateKey);
						result.append(UNITY_SPLITTER);
						result.append(data);
						UnityPlayer.UnitySendMessage(
								GOOGLE_CLOUD_LISTNER_NAME,
								"OnStateResolved", result.toString());
					}

					@Override
					public void onStateConflict(int stateKey,
							String resolvedVersion, byte[] localData,
							byte[] serverData) {
						String dataLocal = ConvertCloudDataToString(localData);
						String dataServer = ConvertCloudDataToString(serverData);
						printLog("resolveState onStateConflict Status:  stateKey: "
								+ stateKey);
						

						StringBuilder result = new StringBuilder();
						result.append(stateKey);
						result.append(UNITY_SPLITTER);
						result.append(dataLocal);
						result.append(UNITY_SPLITTER);
						result.append(dataServer);
						result.append(UNITY_SPLITTER);
						result.append(resolvedVersion);
						UnityPlayer.UnitySendMessage(
								GOOGLE_CLOUD_LISTNER_NAME,
								"OnStateConflict", result.toString());
					}
				}, stateKey, resolvedVersion, stateData);

	
	}

	public void updateState(int stateKey, String data) {
		CloudUpdateState(stateKey, ConvertStringToCloudData(data));
	}

	private void CloudUpdateState(int stateKey, byte[] stateData) {

		mHelper.getAppStateClient().updateStateImmediate(
				new OnStateLoadedListener() {

					@Override
					public void onStateLoaded(int statusCode, int stateKey,
							byte[] localData) {
						String data = ConvertCloudDataToString(localData);
						printLog("onStateLoaded Status: " + statusCode
								+ " stateKey: " + stateKey);

						StringBuilder result = new StringBuilder();
						result.append(statusCode);
						result.append(UNITY_SPLITTER);
						result.append(stateKey);
						result.append(UNITY_SPLITTER);
						result.append(data);
						UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
								"OnStateUpdated", result.toString());
					}

					@Override
					public void onStateConflict(int stateKey,
							String resolvedVersion, byte[] localData,
							byte[] serverData) {
						String dataLocal = ConvertCloudDataToString(localData);
						String dataServer = ConvertCloudDataToString(serverData);
						printLog("resolveState onStateConflict Status:  stateKey: " + stateKey);
					
					

						StringBuilder result = new StringBuilder();
						result.append(stateKey);
						result.append(UNITY_SPLITTER);
						result.append(dataLocal);
						result.append(UNITY_SPLITTER);
						result.append(dataServer);
						result.append(UNITY_SPLITTER);
						result.append(resolvedVersion);
						UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
								"OnStateConflict", result.toString());

					}
				}, stateKey, stateData);

	}

	public void deleteState(int stateKey) {

		mHelper.getAppStateClient().deleteState(new OnStateDeletedListener() {

			@Override
			public void onStateDeleted(int statusCode, int stateKey) {
				printLog("deleteState method: " + Integer.toString(statusCode));
				StringBuilder result = new StringBuilder();
				result.append(statusCode);
				result.append(UNITY_SPLITTER);
				result.append(stateKey);
				UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
						"OnKeyDeleted", result.toString());
			}
		}, stateKey);
	}

	public void loadState(int stateKey) {

		mHelper.getAppStateClient().loadState(new OnStateLoadedListener() {

			@Override
			public void onStateLoaded(int statusCode, int stateKey,
					byte[] localData) {
				String data = ConvertCloudDataToString(localData);
				printLog("onStateLoaded Status: " + statusCode + " stateKey: "
						+ stateKey);
			

				StringBuilder result = new StringBuilder();
				result.append(statusCode);
				result.append(UNITY_SPLITTER);
				result.append(stateKey);
				result.append(UNITY_SPLITTER);
				result.append(data);
				UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
						"OnStateLoaded", result.toString());

			}

			@Override
			public void onStateConflict(int stateKey, String resolvedVersion,
					byte[] localData, byte[] serverData) {
				String dataLocal = ConvertCloudDataToString(localData);
				String dataServer = ConvertCloudDataToString(serverData);
				printLog("resolveState onStateConflict Status:  stateKey: "
						+ stateKey);
			

				StringBuilder result = new StringBuilder();
				result.append(stateKey);
				result.append(UNITY_SPLITTER);
				result.append(dataLocal);
				result.append(UNITY_SPLITTER);
				result.append(dataServer);
				result.append(UNITY_SPLITTER);
				result.append(resolvedVersion);
				UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
						"OnStateConflict", result.toString());
			}

		}, stateKey);
	}

	// --------------------------------------
	// GAME SERVICE METHODS
	// --------------------------------------

	public void LoadPlayer() {
		loadPlayer(mHelper.getGamesClient().getCurrentPlayerId());
	}

	public void loadPlayer(String playerId) {
		mHelper.getGamesClient().loadPlayer(new OnPlayersLoadedListener() {

			@Override
			public void onPlayersLoaded(int statusCode, PlayerBuffer buffer) {
				String name = "";
				String id = "";
				try {
					Player p = buffer.get(0);
					name = p.getDisplayName();
					id = p.getPlayerId();

				} catch (Exception ex) {
					ex.printStackTrace();
				}

				StringBuilder playerInfo = new StringBuilder();
				playerInfo.append(statusCode);
				playerInfo.append(UNITY_SPLITTER);
				playerInfo.append(id);
				playerInfo.append(UNITY_SPLITTER);
				playerInfo.append(name);

				UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
						"OnPlayerLoaded", playerInfo.toString());

			}
		}, playerId);
	}

	// --------------------------------------
	// LEADER_BOARD
	// --------------------------------------

	public void showLeaderBoardsUI() {
		_act.startActivityForResult(mHelper.getGamesClient()
				.getAllLeaderboardsIntent(), LEADER_BOARDS_REQUEST);
	}

	public void showLeaderBoardUI(String leaderboardId) {
		_act.startActivityForResult(mHelper.getGamesClient()
				.getLeaderboardIntent(leaderboardId), LEADER_BOARDS_REQUEST);
	}

	public void submitScore(String leaderboardId, int score) {

		mHelper.getGamesClient().submitScoreImmediate(
				new OnScoreSubmittedListener() {

					@Override
					public void onScoreSubmitted(int statusCode,
							SubmitScoreResult result) {
						printLog("Status: " + statusCode + " leaderboardId: "
								+ result.getLeaderboardId());

						StringBuilder playerInfo = new StringBuilder();
						playerInfo.append(statusCode);
						playerInfo.append(UNITY_SPLITTER);
						playerInfo.append(result.getLeaderboardId());

						UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
								"OnScoreSubmitted", playerInfo.toString());

					}
				}, leaderboardId, score);
	}

	public void loadLeaderBoards() {
		mHelper.getGamesClient().loadLeaderboardMetadata(
				new OnLeaderboardMetadataLoadedListener() {

					@Override
					public void onLeaderboardMetadataLoaded(int statusCode,
							LeaderboardBuffer buffer) {

						StringBuilder leaderboardsInfo = new StringBuilder();
						leaderboardsInfo.append(statusCode);

						if (statusCode == GamesClient.STATUS_OK) {
							leaderboardsInfo.append(UNITY_SPLITTER);

							Iterator<Leaderboard> iterator = buffer.iterator();

							// boolean first = true;
							while (iterator.hasNext()) {
								Leaderboard lb = iterator.next();

								leaderboardsInfo.append(lb.getLeaderboardId());
								leaderboardsInfo.append(UNITY_SPLITTER);
								leaderboardsInfo.append(lb.getDisplayName());
								leaderboardsInfo.append(UNITY_SPLITTER);

								ArrayList<LeaderboardVariant> variants = lb
										.getVariants();
								for (LeaderboardVariant variant : variants) {

									leaderboardsInfo.append(variant
											.getRawPlayerScore());
									leaderboardsInfo.append(UNITY_SPLITTER);
									leaderboardsInfo.append(variant
											.getPlayerRank());
									leaderboardsInfo.append(UNITY_SPLITTER);
									leaderboardsInfo.append(variant
											.getTimeSpan());
									leaderboardsInfo.append(UNITY_SPLITTER);
									leaderboardsInfo.append(variant
											.getCollection());
									leaderboardsInfo.append(UNITY_SPLITTER);
								}

								// first = false;

							}

							leaderboardsInfo.append(UNITY_EOF);
						}

						UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
								"OnLeaderboardDataLoaded",
								leaderboardsInfo.toString());

					}
				});
	}

	@SuppressWarnings("unused")
	private void loadPlayerScore(String leaderboardId) {
		mHelper.getGamesClient().loadPlayerCenteredScores(
				new OnLeaderboardScoresLoadedListener() {

					@Override
					public void onLeaderboardScoresLoaded(int statusCode,
							LeaderboardBuffer leaderboard,
							LeaderboardScoreBuffer scores) {

						Iterator<Leaderboard> iterator = leaderboard.iterator();

						while (iterator.hasNext()) {
							printLog("--------------");
							Leaderboard lb = iterator.next();
							printLog(lb.getLeaderboardId());
							printLog(lb.getDisplayName());

						}
						printLog("-----scores---------");
						printLog("Scores count: ");
						printLog(scores.getCount());
						Iterator<LeaderboardScore> iterator2 = scores
								.iterator();

						while (iterator2.hasNext()) {
							LeaderboardScore lb = iterator2.next();
							printLog(lb.getDisplayRank());
							printLog(lb.getDisplayScore());

						}
						printLog("-------------");

						// Leaderboard lb = leaderboard.get(0);
						// LeaderboardScore sc = scores.get(0);
						// printLog("Status: " + statusCode + " leaderboardId: "
						// + lb.getLeaderboardId() + " Score: " +
						// sc.getDisplayScore());

					}
				}, leaderboardId, LeaderboardVariant.TIME_SPAN_ALL_TIME,
				LeaderboardVariant.COLLECTION_PUBLIC, 25);
	}

	// --------------------------------------
	// ACHIVMENTS
	// --------------------------------------

	public void showAchivmentsUI() {
		_act.startActivityForResult(mHelper.getGamesClient()
				.getAchievementsIntent(), ACHIEVEMENTS_REQUEST);
	}

	public void reportAchievement(String id) {
		mHelper.getGamesClient().unlockAchievementImmediate(
				new OnAchievementUpdatedListener() {

					@Override
					public void onAchievementUpdated(int statusCode,
							String achievementId) {
						printLog("Status: " + statusCode + " achivment: "
								+ achievementId);

						StringBuilder info = new StringBuilder();
						info.append(statusCode);
						info.append(UNITY_SPLITTER);
						info.append(achievementId);

						UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
								"OnAchievementUpdated", info.toString());

					}
				}, id);
	}

	public void incrementAchievement(String id, int numSteps) {
		mHelper.getGamesClient().incrementAchievementImmediate(
				new OnAchievementUpdatedListener() {

					@Override
					public void onAchievementUpdated(int statusCode,
							String achievementId) {
						printLog("Status: " + statusCode + " achivment: "
								+ achievementId);

						StringBuilder info = new StringBuilder();
						info.append(statusCode);
						info.append(UNITY_SPLITTER);
						info.append(achievementId);

						UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
								"OnAchievementUpdated", info.toString());

					}
				}, id, numSteps);
	}

	public void revealAchievement(String id) {
		mHelper.getGamesClient().revealAchievementImmediate(
				new OnAchievementUpdatedListener() {

					@Override
					public void onAchievementUpdated(int statusCode,
							String achievementId) {
						printLog("Status: " + statusCode + " achivment: "
								+ achievementId);

						StringBuilder info = new StringBuilder();
						info.append(statusCode);
						info.append(UNITY_SPLITTER);
						info.append(achievementId);

						UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
								"OnAchievementUpdated", info.toString());
					}
				}, id);

	}

	public void loadAchivments() {
		
		mHelper.getGamesClient().loadAchievements(new OnAchievementsLoadedListener() {

			@Override
			public void onAchievementsLoaded(int statusCode,
					AchievementBuffer buffer) {

				StringBuilder info = new StringBuilder();
				info.append(statusCode);
				info.append(UNITY_SPLITTER);

				Iterator<Achievement> iterator = buffer.iterator();

				while (iterator.hasNext()) {

					Achievement ach = iterator.next();
					info.append(ach.getAchievementId());
					info.append(UNITY_SPLITTER);
					info.append(ach.getName());
					info.append(UNITY_SPLITTER);
					info.append(ach.getDescription());
					info.append(UNITY_SPLITTER);

					if (ach.getType() == Achievement.TYPE_INCREMENTAL) {
						info.append(Integer.toString(ach
								.getCurrentSteps()));
						info.append(UNITY_SPLITTER);
						info.append(Integer.toString(ach
								.getTotalSteps()));
						info.append(UNITY_SPLITTER);
					} else {
						info.append("-1");
						info.append(UNITY_SPLITTER);
						info.append("-1");
						info.append(UNITY_SPLITTER);
					}

					info.append(Integer.toString(ach.getState()));
					info.append(UNITY_SPLITTER);
					info.append(Integer.toString(ach.getType()));
					info.append(UNITY_SPLITTER);

				}

				info.append(UNITY_EOF);
				UnityPlayer.UnitySendMessage(PlAY_SERVICE_LISTNER_NAME,
						"OnAchievementsLoaded", info.toString());

			}
		}, true);
		
	}

	public GamesClient getGamesClient() {
		return mHelper.getGamesClient();
	}

	public boolean isSignedIn() {
		return mHelper.isSignedIn();
	}

	public void beginUserInitiatedSignIn() {
		mHelper.beginUserInitiatedSignIn();
	}

	public void signOut() {
		mHelper.signOut();
	}

	public void showAlert(String title, String message) {
		mHelper.showAlert(title, message);
	}

	public void showAlert(String message) {
		mHelper.showAlert(message);
	}

	protected void enableDebugLog(boolean enabled, String tag) {
		mDebugLog = true;
		mDebugTag = tag;
		if (mHelper != null) {
			mHelper.enableDebugLog(enabled, tag);
		}
	}

	public String getInvitationId() {
		return mHelper.getInvitationId();
	}

	public boolean hasSignInError() {
		return mHelper.hasSignInError();
	}

	public GameHelper.SignInFailureReason getSignInError() {
		return mHelper.getSignInError();
	}

	@Override
	public void onSignInFailed() {
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnSignInFailed",
				"");
	}

	@Override
	public void onSignInSucceeded() {
		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME,
				"OnSignInSucceeded", "");
	}

	@Override
	public void onStateChange(int state) {

		if (state == GameHelper.STATE_CONNECTED) {
			if (!isUnityPartInited) {

				if (mHelper.getAppStateClient() != null
						&& mHelper.getAppStateClient().isConnected()) {
					StringBuilder info = new StringBuilder();

					int maxSize = mHelper.getAppStateClient().getMaxStateSize();
					int maxKeys = mHelper.getAppStateClient().getMaxNumKeys();

					info.append(Integer.toString(maxSize));
					info.append(UNITY_SPLITTER);
					info.append(Integer.toString(maxKeys));

					UnityPlayer.UnitySendMessage(GOOGLE_CLOUD_LISTNER_NAME,
							"OnCloudConnected", info.toString());
				}

				isUnityPartInited = true;
			}
		}

		UnityPlayer.UnitySendMessage(CONNECTION_LISTNER_NAME, "OnStateChange",
				Integer.toString(state));
		Log.d("AndroidNative", "State Changed to: " + GameHelper.STATE_NAMES[state]);

	}

	@SuppressWarnings("unused")
	private void printLog(Long l) {
		printLog(Long.toString(l));
	}

	private void printLog(int i) {
		printLog(Integer.toString(i));
	}

	private void printLog(String msg) {

		Log.d("AndroidNative", "GameClientManager: " + msg);
	}

	private String ConvertCloudDataToString(byte[] data) {
		String b = "";

		int len = data.length;
		for (int i = 0; i < len; i++) {
			if (i != 0) {
				b += ",";
			}

			b += String.valueOf(data[i]);
		}

		return b;
	}

	public static byte[] ConvertStringToCloudData(String data) {
		
		String[] array = data.split("\\,");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			l.add(Byte.valueOf(b));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	public static boolean isStarted() {
		return isStarted;
	}

}
