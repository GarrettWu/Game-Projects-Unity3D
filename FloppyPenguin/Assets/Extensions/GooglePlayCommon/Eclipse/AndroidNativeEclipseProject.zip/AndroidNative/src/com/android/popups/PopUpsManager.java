package com.android.popups;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import com.android.AndroidNativeBridge;
import com.unity3d.player.UnityPlayer;



public class PopUpsManager {
	
	private static String rateUrl;

	public static void ShowMessage(String title, String message, String ok) {
		 AlertDialog.Builder builder = new AlertDialog.Builder(AndroidNativeBridge.GetInstance());
		 builder.setTitle(title);
		 builder.setMessage(message);
		 builder.setPositiveButton(ok, dialogClickListener);
		 builder.setCancelable(false);

		 builder.show();
		 
			
		 
	}
	
	
	public static void ShowDialog(String title, String message, String yes, String no) {
		 AlertDialog.Builder builder = new AlertDialog.Builder(AndroidNativeBridge.GetInstance());
		 builder.setTitle(title);
		 builder.setMessage(message);
		 builder.setPositiveButton(yes, dialogClickListener);
		 builder.setNegativeButton(no, dialogClickListener);
		// builder.setOnDismissListener(dismissListner);
		 builder.setCancelable(false);
		
		 
		 builder.show();
	}
	
	
	
	public static void ShowRateDialog(String title, String message, String yes, String laiter, String no, String url) {
		
		 rateUrl = url;
		 AlertDialog.Builder builder = new AlertDialog.Builder(AndroidNativeBridge.GetInstance());
		 builder.setTitle(title);
		 builder.setMessage(message);
		 builder.setPositiveButton(yes, rateDialogListener);
		 builder.setNegativeButton(no, rateDialogListener);
		 builder.setNeutralButton(laiter, rateDialogListener);
		 //builder.setOnDismissListener(rateDismissListner);
		 builder.setCancelable(false);
		 
		 
		 builder.show();

	}
	
	/*
	private static DialogInterface.OnDismissListener dismissListner = new DialogInterface.OnDismissListener() {
		
		@Override
		public void onDismiss(DialogInterface dialog) {
			UnityPlayer.UnitySendMessage("AndroidPopUp", "onDismissed", "0");
			Log.d("AndroidNative", "dismissed: ");

		}
	};
	
	private static DialogInterface.OnDismissListener rateDismissListner = new DialogInterface.OnDismissListener() {
		
		@Override
		public void onDismiss(DialogInterface dialog) {
			UnityPlayer.UnitySendMessage("AndroidRateUsPopUp", "onDismissed", "0");
			Log.d("AndroidNative", "dismissed: ");

		}
	};
	*/
	
	private static DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
	    @Override
	    public void onClick(DialogInterface dialog, int which) {
	    	
	        switch (which){
	        
	        case DialogInterface.BUTTON_POSITIVE:
	        	UnityPlayer.UnitySendMessage("AndroidPopUp", "onPopUpCallBack", "0");
	            //Yes button clicked
	            break;

	        case DialogInterface.BUTTON_NEGATIVE:
	        	UnityPlayer.UnitySendMessage("AndroidPopUp", "onPopUpCallBack", "1");
	            //No button clicked
	            break;
	        }
	    }
	};
	
	private static DialogInterface.OnClickListener rateDialogListener = new DialogInterface.OnClickListener() {
	    @Override
	    public void onClick(DialogInterface dialog, int which) {
	        switch (which){
	        case DialogInterface.BUTTON_POSITIVE:
	        	UnityPlayer.UnitySendMessage("AndroidRateUsPopUp", "onPopUpCallBack", "0");
				 
				 Uri uri = Uri.parse(rateUrl);	
				 Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				 AndroidNativeBridge.GetInstance().startActivity(intent);
				 
	            //Yes button clicked
	            break;

	        case DialogInterface.BUTTON_NEGATIVE:
	        	UnityPlayer.UnitySendMessage("AndroidRateUsPopUp", "onPopUpCallBack", "2");
	            //No button clicked
	            break;
	            
	        case DialogInterface.BUTTON_NEUTRAL:
	        	UnityPlayer.UnitySendMessage("AndroidRateUsPopUp", "onPopUpCallBack", "1");
	            //neutral button clicked
	            break;
	            
	        }
	    }
	};

}
