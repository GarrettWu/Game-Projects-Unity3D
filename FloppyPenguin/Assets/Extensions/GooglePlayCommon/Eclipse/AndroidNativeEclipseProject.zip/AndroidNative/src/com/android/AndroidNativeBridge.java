package com.android;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.util.Log;
import android.widget.Toast;

import com.android.billing.core.BillingManager;
import com.android.billing.util.Base64;
import com.android.billing.util.Base64DecoderException;
import com.android.features.AlarmReceiver;
import com.android.features.ad.ANMobileAd;
import com.android.features.analytics.ANGoogleAnalytics;
import com.android.features.social.twitter.ANTwitter;
import com.android.gcm.ANCloudMessageService;
import com.android.gs.GameClientManager;
import com.android.popups.PopUpsManager;
import com.facebook.Session;
import com.facebook.unity.FB;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.unity3d.player.UnityPlayerActivity;

public class AndroidNativeBridge extends UnityPlayerActivity {

	private static AndroidNativeBridge inst = null;
	private static BillingManager billing = null;
	private static GameClientManager playService;
	//private static ANCloudMessageService cloudMessage;
	
	
	private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
	

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		inst = this;
		playService = new GameClientManager();

	}
	
	

	public static AndroidNativeBridge GetInstance() {
		return inst;
	}

	// --------------------------------------
	// Google Cloud
	// --------------------------------------

	public void listStates() {
		playService.listStates();
	}

	public void updateState(String stateKey, String data) {
		playService.updateState(Integer.parseInt(stateKey), data);
	}
	

	public void deleteState(String stateKey) {
		playService.deleteState(Integer.parseInt(stateKey));
	}

	public void loadState(String stateKey) {
		playService.loadState(Integer.parseInt(stateKey));
	}

	public void resolveState(String stateKey, String resolvedData,
			String resolvedVersion) {
		playService.resolveState(Integer.parseInt(stateKey), resolvedData,
				resolvedVersion);
	}
	
	// --------------------------------------
	// Google Cloud Message
	// --------------------------------------
	
	public void initCloudMessage(String senderId) {
		 new ANCloudMessageService(this, getApplicationContext(), senderId);
		//sendNotification("initCloudMessage");
	}
	
	/*
	private void sendNotification(String msg) {
		Log.d("AndroidNative", "Notification Sended: ");
		NotificationManager mNotificationManager = (NotificationManager)
	                this.getSystemService(Context.NOTIFICATION_SERVICE);

	        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,new Intent(this, AndroidNativeBridge.class), 0);

	        NotificationCompat.Builder mBuilder =
	                new NotificationCompat.Builder(this)
	        .setContentTitle("Notification")
	        .setStyle(new NotificationCompat.BigTextStyle()
	        .bigText(msg))
	        .setContentText(msg);

	        mBuilder.setContentIntent(contentIntent);
	        mNotificationManager.notify(1, mBuilder.build());
	    }
	    */

	// --------------------------------------
	// Google Play Services
	// --------------------------------------

	public void startPlayService(String clientsToUse) {
		playService.startPlayService(this, clientsToUse);
	}

	public void playServiceConnect() {
		playService.beginUserInitiatedSignIn();
	}

	public void playServiceDisconnect() {
		playService.signOut();
	}

	public void showAchivments() {
		playService.showAchivmentsUI();
	}

	public void showLeaderBoards() {
		playService.showLeaderBoardsUI();
	}

	public void showLeaderBoard(String leaderboardName) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		showLeaderBoardById(leaderboardId);
	}

	public void showLeaderBoardById(String leaderboardId) {
		playService.showLeaderBoardUI(leaderboardId);
	}

	public void loadPlayer() {
		playService.LoadPlayer();
	}

	public void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public void submitScoreById(String leaderboardId, String score) {
		playService.submitScore(leaderboardId, Integer.parseInt(score));
	}

	public void loadLeaderBoards() {
		playService.loadLeaderBoards();
	}

	public void reportAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public void reportAchievementById(String achievementId) {
		playService.reportAchievement(achievementId);
	}

	public void revealAchievement(String achievementName) {
		String achievementId = getStringResourceByName(achievementName);
		revealAchievementById(achievementId);
	}

	public void revealAchievementById(String achievementId) {
		playService.revealAchievement(achievementId);
	}

	public void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public void incrementAchievementById(String achievementId, String numsteps) {
		playService.incrementAchievement(achievementId,
				Integer.parseInt(numsteps));
	}

	public void loadAchivments() {
		playService.loadAchivments();
	}

	// --------------------------------------
	// BILLING
	// --------------------------------------

	public void connectToBilling(String ids, String base64EncodedPublicKey) {
		billing = new BillingManager(this);

		ArrayList<String> products = new ArrayList<String>();
		String[] result = ids.split(",");

		for (String id : result) {
			products.add(id);
		}

		billing.connect(products, base64EncodedPublicKey);
	}

	public void retrieveProducDetails() {
		billing.retrieveProducDetails();
	}

	public void consume(String SKU) {
		billing.consume(SKU);
	}

	public void purchase(String SKU, String developerPayload) {
		billing.purchase(SKU, developerPayload);
	}

	// --------------------------------------
	// MESSAGING
	// --------------------------------------

	public void ShowMessage(String title, String message, String ok) {
		PopUpsManager.ShowMessage(title, message, ok);
	}

	public void showDialog(String title, String message, String yes, String no) {
		PopUpsManager.ShowDialog(title, message, yes, no);
	}

	public void ShowRateDialog(String title, String message, String yes,
			String laiter, String no, String url) {
		PopUpsManager.ShowRateDialog(title, message, yes, laiter, no, url);
	}

	// --------------------------------------
	// OTHER FEATURES
	// --------------------------------------

	
	public void InitMobileAd(String id) {
		ANMobileAd.GetInstance().Init(id, this);
	}
	
	public void ChangeBannersUnitID(String id) {
		ANMobileAd.GetInstance().ChangeBannersUnitID(id);
	}
	
	public void ChangeInterstisialsUnitID(String id) {
		ANMobileAd.GetInstance().ChangeInterstisialsUnitID(id);
	}
	
	public void AddKeyword(String keyword) {
		ANMobileAd.GetInstance().AddKeyword(keyword);
	}
	
	public void AddTestDevice(String deviceId) {
		ANMobileAd.GetInstance().AddTestDevice(deviceId);
	}
	
	public void SetGender(String gender) {
		ANMobileAd.GetInstance().SetGender(Integer.parseInt(gender));
	}
	
	public void CreateBannerAd(String gravity, String size, String id) {
		ANMobileAd.GetInstance().CreateBannerAd(Integer.parseInt(gravity), Integer.parseInt(size), Integer.parseInt(id));
	}
	
	public void CreateBannerAdPos(String x, String y, String size, String id) {
		ANMobileAd.GetInstance().CreateBannerAd(Integer.parseInt(x), Integer.parseInt(y), Integer.parseInt(size), Integer.parseInt(id));
	}

	public void HideAd(String id) {
		ANMobileAd.GetInstance().HideAd(Integer.parseInt(id));
	}

	public void ShowAd(String id) {
		ANMobileAd.GetInstance().ShowAd(Integer.parseInt(id));
	}
	

	public void RefreshAd(String id) {
		ANMobileAd.GetInstance().Refresh(Integer.parseInt(id));
	}
	
	public void DestroyBanner(String id) {
		ANMobileAd.GetInstance().DestroyBanner(Integer.parseInt(id));
	}
	
	public void StartInterstitialAd() {
		ANMobileAd.GetInstance().StartInterstitialAd();
	}
	
	public void LoadInterstitialAd() {
		ANMobileAd.GetInstance().LoadInterstitialAd();
	}
	
	public void ShowInterstitialAd() {
		ANMobileAd.GetInstance().ShowInterstitialAd();
	}
	
	
	
	
	

	public void ShowToastNotification(String text, String duration) {
		Context context = getApplicationContext();

		Toast toast = Toast.makeText(context, text, Integer.parseInt(duration));
		toast.show();
	}

	public void scheduleNotification() {
		Log.d("AndroidNative", "scheduleNotification onStart: ");
		// get a Calendar object with current time
		Calendar cal = Calendar.getInstance();
		// add 5 minutes to the calendar object
		cal.add(Calendar.SECOND, 10);
		Intent intent = new Intent(getBaseContext(), AlarmReceiver.class);
		intent.putExtra("alarm_message", "O'Doyle Rules!");

		// In reality, you would want to have a static variable for the request
		// code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(this, 192837, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);

		// Get the AlarmManager service
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
	}
	
	public void notifyUser(){
		 
		Log.d("AndroidNative", "notifyUser onStart: ");
		
		NotificationCompat.Builder mBuilder =
		        new NotificationCompat.Builder(this)
		        .setContentTitle("My notification")
		        .setContentText("Hello World!");
		// Creates an explicit intent for an Activity in your app
		Intent resultIntent = new Intent(this, AlarmReceiver.class);

		// The stack builder object will contain an artificial back stack for the
		// started Activity.
		// This ensures that navigating backward from the Activity leads out of
		// your application to the Home screen.
		TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
		// Adds the back stack for the Intent (but not the Intent itself)
		stackBuilder.addParentStack(AlarmReceiver.class);
		// Adds the Intent that starts the Activity to the top of the stack
		stackBuilder.addNextIntent(resultIntent);
		PendingIntent resultPendingIntent =
		        stackBuilder.getPendingIntent(
		            100500,
		            PendingIntent.FLAG_UPDATE_CURRENT
		        );
		mBuilder.setContentIntent(resultPendingIntent);
		NotificationManager mNotificationManager =
		    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		// mId allows you to update the notification later on.
		mNotificationManager.notify(100500, mBuilder.build());
	 
	}
	
	/*
	public Drawable getFullResDefaultActivityIcon() {
	    return getFullResIcon(Resources.getSystem(), android.R.mipmap.sym_def_app_icon);
	}

	public Drawable getFullResIcon(Resources resources, int iconId) {
	    Drawable d;
	    try {
	        ActivityManager activityManager = (ActivityManager) getBaseContext().getSystemService(Context.ACTIVITY_SERVICE);
	        int iconDpi = activityManager.getLauncherLargeIconDensity();
	        d = resources.getDrawableForDensity(iconId, iconDpi);
	    } catch (Resources.NotFoundException e) {
	        d = null;
	    }

	    return (d != null) ? d : getFullResDefaultActivityIcon();
	}
	*/

	// --------------------------------------
	// Analytics
	// --------------------------------------
	
	public void startAnalyticsTracking() {
		ANGoogleAnalytics.GetInstance().startAnalyticsTracking(this);
	}
	
	
	public void SetTrackerID(String trackingID) {
		ANGoogleAnalytics.GetInstance().SetTracker(trackingID);
	}
	
	 public void SendView(String appScreen) {
		 ANGoogleAnalytics.GetInstance().SendView(appScreen);
	  }
	    
	 public void SendView() {
		 ANGoogleAnalytics.GetInstance().SendView();
	 }
	 
	 
	 public void SendEvent(String category, String action, String label, String value) {
		 ANGoogleAnalytics.GetInstance().sendEvent(category, action, label, value);
	 }
	    
	 public void SendEvent(String category, String action, String label, String value, String key, String val) {
		 ANGoogleAnalytics.GetInstance().sendEvent(category, action, label, value, key, val);
	 }
	
	 public void SetKey(String key, String value) {
		 ANGoogleAnalytics.GetInstance().setKey(key, value);
	 }
	    
	 
	 public void ClearKey(String key) {
		 ANGoogleAnalytics.GetInstance().clearKey(key);
	 }
	    
	 public void SendTiming(String category, String intervalInMilliseconds, String name, String label) {
		 ANGoogleAnalytics.GetInstance().sendTiming(category, intervalInMilliseconds, name, label);
	 }
	 
	 
	  public void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
		  ANGoogleAnalytics.GetInstance().CreateTransaction(transactionId, affiliation, revenue, tax, shipping, currencyCode);
	  }
	    
	  public void CreateItem(String transactionId, String name, String sku, String category, String price, String quantity, String currencyCode) {
		  ANGoogleAnalytics.GetInstance().CreateItem(transactionId, name, sku, category, price, quantity, currencyCode);
	  }
	 
	 public void SetLogLevel(String lvl) {
		 ANGoogleAnalytics.GetInstance().SetLogLevel(Integer.parseInt(lvl));
	 }
	 
	 public void SetDryRun(String mode) {
		 
		 boolean m = false;
		 if(mode.equals("true")) {
			 m = true;
		 } else {
			 m = false;
		 }
		 ANGoogleAnalytics.GetInstance().setDryRun(m);
	 }
	 
	 
	// --------------------------------------
	// Twitter
	// --------------------------------------
	 
	 public void TwitterInit(String consumer_key, String consumer_secret) {
		 Log.d("AndroidNative", "hello: ");
		 ANTwitter.GetInstance().Init(consumer_key, consumer_secret, this);
	 }
	 
	 public void AuthificateUser() {
		 ANTwitter.GetInstance().AuthificateUser();
	 }
	 
	 public void LoadUserData() {
		 ANTwitter.GetInstance().LoadUserData();
	 }
	 
	 public void TwitterPost(String status) {
		 ANTwitter.GetInstance().Twitt(status);
	 }
	 
	 public void TwitterPostWithImage(String status, String data) throws IOException, Base64DecoderException {
		 Log.d("AndroidNative", "TwitterPostWithImage: ");
		 byte[] byteArray = Base64.decode(data); //GameClientManager.ConvertStringToCloudData(data);
		 
		 Log.d("AndroidNative", "converted: ");

		 File tempFile;
		 tempFile = new File(this.getCacheDir(), "twitter_post_image");
		 FileOutputStream fos = new FileOutputStream(tempFile);
		 fos.write(byteArray);
	
		
		 
		 ANTwitter.GetInstance().Twitt(status, tempFile);
	 }
	 
	 public void LogoutFromTwitter() {
		 ANTwitter.GetInstance().logoutFromTwitter();
	 }
	 
	 
			
	
	// --------------------------------------
	// Override
	// --------------------------------------

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (billing != null) {
			billing.handleActivityResult(requestCode, resultCode, data);
		}

		if (GameClientManager.isStarted()) {
			playService.onActivityResult(requestCode, resultCode, data);
		}

		Session session = Session.getActiveSession();
		if(session != null) {
			Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
		}
		

	}
	
   @Override
   public void onNewIntent(Intent intent) {
	    Log.d("AndroidNative", "onNewIntent: ");
        super.onNewIntent(intent);
        FB.SetIntent(intent);
        ANTwitter.GetInstance().SetIntent(intent);
   }

	@Override
	public void onDestroy() {
		super.onDestroy();

		if (billing != null) {
			billing.dispose();
		}
		billing = null;
	}

	@Override
	protected void onStart() {
		super.onStart();
		if (GameClientManager.isStarted()) {
			Log.d("AndroidNative", "playService onStart: ");
			playService.onStart(this);
		}

	}
	
	 /**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     */
	 public  boolean checkPlayServices() {
	        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
	        if (resultCode != ConnectionResult.SUCCESS) {
	            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
	                GooglePlayServicesUtil.getErrorDialog(resultCode, this, PLAY_SERVICES_RESOLUTION_REQUEST).show();
	            } else {
	                Log.i("AndroidNative", "This device is not supported.");
	                finish();
	            }
	            return false;
	        }
	        return true;
	    }

	@Override
	protected void onStop() {
		super.onStop();

		if (GameClientManager.isStarted()) {
			playService.onStop();
		}
		
		ANGoogleAnalytics.GetInstance().activityStop();

	}

	// --------------------------------------
	// Private Methods
	// --------------------------------------

	private String getStringResourceByName(String aString) {
		String packageName = getPackageName();
		int resId = getResources()
				.getIdentifier(aString, "string", packageName);
		return getString(resId);
	}

}
