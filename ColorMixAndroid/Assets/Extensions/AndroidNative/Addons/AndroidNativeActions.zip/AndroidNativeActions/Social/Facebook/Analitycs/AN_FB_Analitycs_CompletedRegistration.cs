﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Social")]
	public class AN_FB_Analitycs_CompletedRegistration : FsmStateAction {

		public FsmString RegistrationMethod;
		
		public override void OnEnter() {
			SPFacebookAnalytics.CompletedRegistration(RegistrationMethod.Value);
			Finish ();
		}	
	}
}
