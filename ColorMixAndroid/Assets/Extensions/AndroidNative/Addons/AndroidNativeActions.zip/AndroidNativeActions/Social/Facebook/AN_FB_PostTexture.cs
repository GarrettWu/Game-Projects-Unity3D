using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_PostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			SPFacebook.instance.addEventListener(FacebookEvents.POST_FAILED,  			OnPostFailed);
			SPFacebook.instance.addEventListener(FacebookEvents.POST_SUCCEEDED,   		OnPostSuccses);
			
			SPFacebook.instance.PostImage(message.Value, texture.Value as Texture2D);
			
		}


		private void RemoveListners() {
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_FAILED,  			OnPostFailed);
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_SUCCEEDED,   		OnPostSuccses);
		}
		
		
		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}
		
	}
}



