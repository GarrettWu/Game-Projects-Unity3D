var searchData=
[
  ['initialize',['initialize',['../class_google_universal_analytics.html#a9641fada369d2870ff61acaa879f522a',1,'GoogleUniversalAnalytics']]],
  ['instance',['Instance',['../class_google_universal_analytics.html#ae4d2ea36ead3883e306d11060b9d391a',1,'GoogleUniversalAnalytics']]]
];
