﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_SubmitScore : FsmStateAction {

		public FsmString leaderboardId;
		public FsmInt score;


		public override void OnEnter() {
			GameCenterManager.reportScore(score.Value, leaderboardId.Value);
			Finish();
			
		}

	}
}

